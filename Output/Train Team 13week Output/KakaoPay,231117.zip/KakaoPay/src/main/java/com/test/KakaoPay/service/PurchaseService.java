package com.test.KakaoPay.service;

import com.test.KakaoPay.domain.Purchase;

public interface PurchaseService{
    Purchase paymentKakaoPay(String itemName,String cost);
}
