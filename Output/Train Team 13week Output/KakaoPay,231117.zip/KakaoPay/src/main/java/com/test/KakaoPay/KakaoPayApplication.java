package com.test.KakaoPay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KakaoPayApplication {

	public static void main(String[] args) {
		SpringApplication.run(KakaoPayApplication.class, args);
	}

}
