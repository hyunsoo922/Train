package com.test.KakaoPay.controller;

import com.test.KakaoPay.domain.Purchase;
import com.test.KakaoPay.service.PurchaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping
public class PurchaseController {

    @Autowired
    private PurchaseService purchaseService;

    @RequestMapping("/")
    public String getPurchase(Model model)
    {
        model.addAttribute("cost","10000");
        model.addAttribute("bookName","난생처음 파이썬 프로그래밍");

        return "payment";
    }

    @GetMapping("/payment")
    public @ResponseBody Purchase payment(@RequestParam String itemName, @RequestParam String cost)
    {
        Purchase response = purchaseService.paymentKakaoPay(itemName,cost);

        System.out.println("결제고유번호: "+ response.getTid());
        System.out.println("결제요청 URL"+response.getNext_redirect_pc_url());

        return response;
    }

    @GetMapping("/purchase/success")
    public String success()
    {
        return "/purchase/success";
    }

    @GetMapping("/purchase/cancle")
    public String cancle()
    {
        return "/purchase/cancle";
    }

    @GetMapping("/purchase/fail")
    public String fail()
    {
        return "/purchase/fail";
    }
}
