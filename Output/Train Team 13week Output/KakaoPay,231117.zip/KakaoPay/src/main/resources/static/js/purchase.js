$(function(){
    $("#paymentBtn").click(function(){
        let name = $("#bookName").val();
        let cost = $("#cost").val();

        $.ajax({
            url: "/payment",
            type: "GET",
            data:{
                "itemName": name,
                "cost": cost,
            },
            success:function(response)
            {
                location.href = response.next_redirect_pc_url;
            }
        });
    });

});