package com.test.KakaoPay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakaoPayApplicationTests {

	@Test
	void contextLoads() {
	}

}
