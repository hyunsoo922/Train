import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import time
import urllib.request
from PIL import Image
import pytesseract
import requests
import os

print('시작')

# 웹 드라이버 초기화
driver = webdriver.Chrome()

# id = input('LMS 아이디를 입력해 주세요')
# ps = input('LMS 비밀번호를 입력해주세요')

id = '18102034'
ps = '990922'

# LMS 로그인 페이지 접속
driver.get("https://sso.nsu.ac.kr/login?redirect_url=https%3A%2F%2Fmypage.nsu.ac.kr%2Fmypage%2Fstudent%2F")

# 아이디 입력란 찾고 입력

elem = driver.find_element(By.ID, 'id_input')
elem.send_keys(id)

# 패스워드 입력란 찾고 입력
password_input = driver.find_element(By.ID, 'password_input')
password_input.send_keys(ps)
password_input.send_keys(Keys.RETURN)

# 페이지가 로딩될 때까지 1초 대기
time.sleep(1)

# 수강신청조회(확인서) 페이지 열기
driver.get("https://mypage.nsu.ac.kr/mypage/student/?m1=A00020%2FHSK511%25")

# 페이지가 로딩될 때까지 1초 대기
time.sleep(1)

# 수강신청 리스트의 담당교수 버튼 XPATH 주소
# tr[2]부터 1씩 증가시키면 각 강의의 수업계획서에 접근 가능
index1 = 2
a = '//*[@id="wrapper"]/div[1]/div/div/div[6]/div[1]/div/table/tbody/tr['
b = ']/td[11]'

# 수업계획서 내 주교재 항목 XPATH 주소
index2 = 1
c = '//*[@id=\"popup_layout_list\"]/div/div[2]/div[2]/div/div[2]/div/table/tbody/tr['
d = ']/td[3]/span'

list = []

while True:
    # 담당교수 버튼 XPATH 조합
    menu_button_xpath = a + str(index1) + b
    try:
        # 담당교수 버튼을 찾고 클릭
        menu_button = driver.find_element(By.XPATH, menu_button_xpath)
        menu_button.click()
        time.sleep(0.1)
        while True:
            # 주교재 항목 XPATH 조합
            menu_button_xpath = c + str(index2) + d
            try:
                # 주교재 항목 찾고 교재명 추출
                element = driver.find_element(By.XPATH, menu_button_xpath)
                text_content = element.text
                # 교재명 출력
                #print(text_content)
                time.sleep(0.1)
                list.append(text_content)
                break
            # 주교재 명이 없을 시
            except NoSuchElementException:
                # 다음 항목 검색
                index2 += 1
                # 반복문 초기로
                continue
        time.sleep(0.1)
        # 다음 강의의 담당교수 버튼으로 이동하기 위해 XPATH 수정
        index1 += 1
        time.sleep(0.1)
        # x 버튼을 찾고 클릭
        menu_button = driver.find_element(By.XPATH, "//*[@id=\"popup_layout_list\"]/div/div[2]/div[1]/img")
        menu_button.click()
        time.sleep(0.1)
        # 주교재 항목 XPATH 초기화
        index2 = 1
    # 수강신청 리스트 페이지에서 수강신청한 강의를 찾지 못할 시
    except NoSuchElementException:
        print('종료')
        break

list = [item for item in list if len(item) >= 5]
print(list)

# 알라딘 API 키
aladin_api_key = "ttbskrheem9911161529001"

def search_book(api_key, query):

    # 이미지를 저장할 경로
    image_output_path = "C:/Users/skrheem/Downloads/selenium/알라딘/이미지"

    # 결과를 저장할 파일 경로
    info_output_path = os.path.join("C:/Users/skrheem/Downloads/selenium/알라딘/정보", f"{query}.txt")


    # 알라딘 API 엔드포인트
    api_url = "http://www.aladin.co.kr/ttb/api/ItemSearch.aspx"

    # API 파라미터 설정
    params = {
        'ttbkey': api_key,  # 알라딘 API 키
        'Query': query,     # 검색할 책 제목
        'output': 'js',     # 결과 형식 (json 형식 선택)
        'Version': '20131101'  # API 버전
    }

    # API 호출
    response = requests.get(api_url, params=params)
    data = response.json()

    # 책 정보 저장
    with open(info_output_path, 'w', encoding='utf-8') as output_file:
        if 'item' in data:
            for book in data['item']:
                output_file.write(f"책 제목: {book.get('title', '정보 없음')}\n")
                output_file.write(f"작가: {book.get('author', '정보 없음')}\n")
                
                # 'priceStandard' 키의 존재 여부 확인 후 값 저장
                if 'priceStandard' in book:
                    output_file.write(f"가격: {book['priceStandard']} 원\n")
                else:
                    output_file.write("가격 정보 없음\n")

                output_file.write(f"책 소개: {book.get('description', '정보 없음')}\n")
                output_file.write(f"isbn13: {book.get('isbn13', '정보 없음')}\n\n")

                # 이미지 다운로드 및 저장
                image_url = book.get(f'cover', {book.get('cover', '정보 없음')})
                if image_url:
                    image_response = requests.get(image_url)
                    image_filename = os.path.join(image_output_path, f"{query}.jpg")
                    with open(image_filename, 'wb') as image_file:
                        image_file.write(image_response.content)
                else:
                    output_file.write("이미지 정보 없음\n")
        else:
            output_file.write("검색 결과가 없습니다.")

for item in list:
    search_book(aladin_api_key, item)