import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import time
import urllib.request
from PIL import Image
import pytesseract

print('시작')

# 웹 드라이버 초기화
driver = webdriver.Chrome()

# id = input('LMS 아이디를 입력해 주세요')
# ps = input('LMS 비밀번호를 입력해주세요')

id = '18102101'
ps = 'sk991116!'

# LMS 로그인 페이지 접속
driver.get("https://sso.nsu.ac.kr/login?redirect_url=https%3A%2F%2Fmypage.nsu.ac.kr%2Fmypage%2Fstudent%2F")

# 아이디 입력란 찾고 입력

elem = driver.find_element(By.ID, 'id_input')
elem.send_keys(id)

# 패스워드 입력란 찾고 입력
password_input = driver.find_element(By.ID, 'password_input')
password_input.send_keys(ps)
password_input.send_keys(Keys.RETURN)

# 페이지가 로딩될 때까지 1초 대기
time.sleep(1)

# 수강신청조회(확인서) 페이지 열기
driver.get("https://mypage.nsu.ac.kr/mypage/student/?m1=A00020%2FHSK511%25")

# 페이지가 로딩될 때까지 1초 대기
time.sleep(1)

# 수강신청 리스트의 담당교수 버튼 XPATH 주소
# tr[2]부터 1씩 증가시키면 각 강의의 수업계획서에 접근 가능
index1 = 2
a = '//*[@id="wrapper"]/div[1]/div/div/div[6]/div[1]/div/table/tbody/tr['
b = ']/td[11]'

# 수업계획서 내 주교재 항목 XPATH 주소
index2 = 1
c = '//*[@id=\"popup_layout_list\"]/div/div[2]/div[2]/div/div[2]/div/table/tbody/tr['
d = ']/td[3]/span'

list = []

while True:
    # 담당교수 버튼 XPATH 조합
    menu_button_xpath = a + str(index1) + b
    try:
        # 담당교수 버튼을 찾고 클릭
        menu_button = driver.find_element(By.XPATH, menu_button_xpath)
        menu_button.click()
        time.sleep(0.1)
        while True:
            # 주교재 항목 XPATH 조합
            menu_button_xpath = c + str(index2) + d
            try:
                # 주교재 항목 찾고 교재명 추출
                element = driver.find_element(By.XPATH, menu_button_xpath)
                text_content = element.text
                # 교재명 출력
                #print(text_content)
                time.sleep(0.1)
                list.append(text_content)
                break
            # 주교재 명이 없을 시
            except NoSuchElementException:
                # 다음 항목 검색
                index2 += 1
                # 반복문 초기로
                continue
        time.sleep(0.1)
        # 다음 강의의 담당교수 버튼으로 이동하기 위해 XPATH 수정
        index1 += 1
        time.sleep(0.1)
        # x 버튼을 찾고 클릭
        menu_button = driver.find_element(By.XPATH, "//*[@id=\"popup_layout_list\"]/div/div[2]/div[1]/img")
        menu_button.click()
        time.sleep(0.1)
        # 주교재 항목 XPATH 초기화
        index2 = 1
    # 수강신청 리스트 페이지에서 수강신청한 강의를 찾지 못할 시
    except NoSuchElementException:
        print('종료')
        break
    
print(list)